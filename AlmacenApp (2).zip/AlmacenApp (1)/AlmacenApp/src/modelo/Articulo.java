package modelo;

import java.text.Normalizer;

public class Articulo {
	private String nombre; // clave/display usada históricamente
	private String nombreOriginal; // nuevo: mantener el nombre tal como lo ingresó el usuario
	private int stock;
	private int nivelCritico;

	public Articulo(String nombre, int stock, int nivelCritico) {
		this.nombre = nombre; // mantener compatibilidad
		this.nombreOriginal = nombre;
		this.stock = stock;
		this.nivelCritico = nivelCritico;
	}

	public String getNombre() {
		return nombreOriginal != null ? nombreOriginal : nombre;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public boolean esCritico() {
		return stock <= nivelCritico;
	}

	public void ingresar(int cantidad) {
		if (cantidad > 0) {
			stock += cantidad;
		}
	}

	public boolean retirar(int cantidad) {
		if (cantidad > 0 && cantidad <= stock) {
			stock -= cantidad;
			return true;
		}
		return false;
	}

	// Nuevo: normaliza cadenas (quita tildes y pasa a minúsculas) para comparaciones
	private static String normalizarClave(String s) {
		if (s == null)
			return "";
		String n = s.trim().toLowerCase();
		n = Normalizer.normalize(n, Normalizer.Form.NFD);
		return n.replaceAll("\\p{M}", "");
	}

	// Nuevo: equals/hashCode basados en nombre normalizado (evita duplicados lógicos)
	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		Articulo other = (Articulo) o;
		return normalizarClave(this.getNombre()).equals(normalizarClave(other.getNombre()));
	}

	@Override
	public int hashCode() {
		return normalizarClave(getNombre()).hashCode();
	}

	@Override
	public String toString() {
		return String.format("Articulo{name='%s', stock=%d, nivelCritico=%d}", getNombre(), stock, nivelCritico);
	}
}