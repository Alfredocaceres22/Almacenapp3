package modelo;

import java.text.Normalizer;
import java.util.*;
import java.util.stream.Collectors;

public class Inventario {
	// mapa por clave normalizada -> Articulo (mantiene nombre original dentro de Articulo)
	private Map<String, Articulo> articulosPorClave = new HashMap<>();

	// normaliza: quita tildes y pasa todo a minúsculas
	private String normalizar(String s) {
		if (s == null) return "";
		String n = s.trim().toLowerCase();
		n = Normalizer.normalize(n, Normalizer.Form.NFD);
		return n.replaceAll("\\p{M}", "");
	}

	// NUEVO: sobrecarga para compatibilidad cuando se llama con (nombre, stock)
	public void agregarArticulo(String nombre, int stock) {
		// nivel crítico por defecto 5
		agregarArticulo(nombre, stock, 5);
	}

	// Nuevo: agrega un artículo explícitamente (crea o actualiza stock/nivel crítico)
	public void agregarArticulo(String nombre, int stock, int nivelCritico) {
		if (nombre == null || nombre.trim().isEmpty() || stock < 0) return;
		String clave = normalizar(nombre);
		Articulo existente = articulosPorClave.get(clave);
		if (existente == null) {
			Articulo nuevo = new Articulo(nombre.trim(), stock, nivelCritico);
			articulosPorClave.put(clave, nuevo);
		} else {
			// si ya existe, sumar stock y mantener nivelCritico existente
			if (stock > 0) existente.ingresar(stock);
			// si necesita actualizar nivelCritico en existentes, añada un setter en Articulo y descomente/ajuste aquí
		}
	}

	// registra ingreso (crea artículo si no existe)
	public void registrarIngreso(String nombre, int cantidad) {
		if (nombre == null || nombre.trim().isEmpty() || cantidad <= 0) return;
		String clave = normalizar(nombre);
		Articulo a = articulosPorClave.get(clave);
		if (a == null) {
			// usar nivelCritico por defecto 5 (ajuste si su proyecto requiere otro valor)
			agregarArticulo(nombre.trim(), cantidad, 5);
		} else {
			a.ingresar(cantidad);
		}
	}

	// registra retiro; devuelve true si se pudo retirar
	public boolean registrarRetiro(String nombre, int cantidad) {
		if (nombre == null || nombre.trim().isEmpty() || cantidad <= 0) return false;
		String clave = normalizar(nombre);
		Articulo a = articulosPorClave.get(clave);
		if (a == null) return false;
		return a.retirar(cantidad);
	}

	// devuelve lista de artículos (manteniendo nombre original para mostrar)
	public List<Articulo> obtenerArticulos() {
		return articulosPorClave.values().stream()
			.sorted(Comparator.comparing(Articulo::getNombre, String.CASE_INSENSITIVE_ORDER))
			.collect(Collectors.toList());
	}
}