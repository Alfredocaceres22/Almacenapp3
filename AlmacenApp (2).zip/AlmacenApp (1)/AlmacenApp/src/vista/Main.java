package vista;

import javax.swing.SwingUtilities;
import modelo.Inventario;

public class Main {
    public static void main(String[] args) {
        // Crear inventario y datos de ejemplo
        Inventario inventario = new Inventario();
        inventario.agregarArticulo("Café", 10);
        inventario.agregarArticulo("Azúcar", 3);
        inventario.agregarArticulo("Leche", 0);

        // Lanzar GUI en el hilo de eventos
        SwingUtilities.invokeLater(() -> {
            VentanaInventario ventana = new VentanaInventario(inventario);
            ventana.setVisible(true);
        });
    }
}