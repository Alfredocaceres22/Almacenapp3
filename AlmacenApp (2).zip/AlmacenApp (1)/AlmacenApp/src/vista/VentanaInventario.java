package vista;

import javax.swing.*;
import java.awt.*;
import modelo.Inventario;
import modelo.Articulo;

public class VentanaInventario extends JFrame {
    private Inventario inventario;
    private JTextArea areaTexto;

    public VentanaInventario(Inventario inventario) {
        this.inventario = inventario;
        setTitle("Gestión de Inventario");
        setSize(600, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        inicializarComponentes();
        // show window and initial state
        setVisible(true);
        mostrarInventario();
    }

    private void inicializarComponentes() {
        areaTexto = new JTextArea();
        areaTexto.setEditable(false);
        JScrollPane scroll = new JScrollPane(areaTexto);

        JButton btnIngreso = new JButton("Registrar ingreso");
        JButton btnVender = new JButton("Vender artículo");
        JButton btnInventario = new JButton("Ver inventario");
        JButton btnCritico = new JButton("Ver stock crítico");
        JButton btnAgregar = new JButton("Agregar artículo"); // NUEVO

        btnIngreso.addActionListener(e -> registrarIngreso());
        btnVender.addActionListener(e -> registrarRetiro());
        btnInventario.addActionListener(e -> mostrarInventario());
        btnCritico.addActionListener(e -> mostrarCriticos());
        btnAgregar.addActionListener(e -> agregarArticulo()); // NUEVO

        JPanel botones = new JPanel(new GridLayout(1, 5, 10, 10)); // ajustado a 5 columnas
        botones.add(btnIngreso);
        botones.add(btnVender);
        botones.add(btnInventario);
        botones.add(btnCritico);
        botones.add(btnAgregar); // añadido

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(scroll, BorderLayout.CENTER);
        panel.add(botones, BorderLayout.SOUTH);

        add(panel);
    }

    private void registrarIngreso() {
        String nombre = JOptionPane.showInputDialog(this, "Nombre del artículo:");
        if (nombre == null || nombre.trim().isEmpty()) {
            mostrarMensaje("Operación cancelada o nombre vacío.");
            return;
        }
        String cantidadStr = JOptionPane.showInputDialog(this, "Cantidad a ingresar:");
        if (cantidadStr == null || cantidadStr.trim().isEmpty()) {
            mostrarMensaje("Operación cancelada o cantidad inválida.");
            return;
        }
        try {
            int cantidad = Integer.parseInt(cantidadStr.trim());
            if (cantidad <= 0) {
                mostrarMensaje("Ingrese una cantidad mayor que 0.");
                return;
            }
            // pasar el nombre original; Inventario normaliza internamente
            inventario.registrarIngreso(nombre.trim(), cantidad);
            mostrarMensaje("Ingreso registrado.");
            mostrarInventario(); // refresh view
        } catch (NumberFormatException ex) {
            mostrarMensaje("Cantidad inválida.");
        }
    }

    private void registrarRetiro() {
        String nombre = JOptionPane.showInputDialog(this, "Nombre del artículo:");
        if (nombre == null || nombre.trim().isEmpty()) {
            mostrarMensaje("Operación cancelada o nombre vacío.");
            return;
        }
        String cantidadStr = JOptionPane.showInputDialog(this, "Cantidad a vender:");
        if (cantidadStr == null || cantidadStr.trim().isEmpty()) {
            mostrarMensaje("Operación cancelada o cantidad inválida.");
            return;
        }
        try {
            int cantidad = Integer.parseInt(cantidadStr.trim());
            if (cantidad <= 0) {
                mostrarMensaje("Ingrese una cantidad mayor que 0.");
                return;
            }
            // pasar nombre original; Inventario lo buscará normalizando
            boolean exito = inventario.registrarRetiro(nombre.trim(), cantidad);
            if (exito) {
                mostrarMensaje("Venta registrada.");
            } else {
                mostrarMensaje("Stock insuficiente o artículo no encontrado.");
            }
            mostrarInventario(); // refresh view
        } catch (NumberFormatException ex) {
            mostrarMensaje("Cantidad inválida.");
        }
    }

    // NUEVO: permite agregar/crear artículo con stock y nivel crítico
    private void agregarArticulo() {
        String nombre = JOptionPane.showInputDialog(this, "Nombre del artículo:");
        if (nombre == null || nombre.trim().isEmpty()) {
            mostrarMensaje("Operación cancelada o nombre vacío.");
            return;
        }
        String stockStr = JOptionPane.showInputDialog(this, "Stock inicial (número):");
        if (stockStr == null || stockStr.trim().isEmpty()) {
            mostrarMensaje("Operación cancelada o stock inválido.");
            return;
        }
        String nivelStr = JOptionPane.showInputDialog(this, "Nivel crítico (número, opcional - dejar vacío para 5):");
        if (nivelStr == null) { // usuario canceló
            mostrarMensaje("Operación cancelada.");
            return;
        }
        try {
            int stock = Integer.parseInt(stockStr.trim());
            if (stock < 0) {
                mostrarMensaje("Stock no puede ser negativo.");
                return;
            }
            int nivelCritico = 5; // valor por defecto
            if (!nivelStr.trim().isEmpty()) {
                nivelCritico = Integer.parseInt(nivelStr.trim());
                if (nivelCritico < 0) nivelCritico = 5;
            }
            inventario.agregarArticulo(nombre.trim(), stock, nivelCritico);
            mostrarMensaje("Artículo agregado/actualizado.");
            mostrarInventario();
        } catch (NumberFormatException ex) {
            mostrarMensaje("Valores numéricos inválidos.");
        }
    }

    private void mostrarInventario() {
        StringBuilder sb = new StringBuilder();
        sb.append("Inventario total:\n");
        boolean hay = false;
        for (Articulo a : inventario.obtenerArticulos()) {
            hay = true;
            sb.append("- ").append(a.getNombre()).append(": ").append(a.getStock()).append(" unidades\n");
        }
        if (!hay) {
            sb.append("(no hay artículos)\n");
        }
        areaTexto.setText(sb.toString());
    }

    private void mostrarCriticos() {
        StringBuilder sb = new StringBuilder();
        sb.append("Artículos en nivel crítico:\n");
        boolean hay = false;
        for (Articulo a : inventario.obtenerArticulos()) {
            if (a.esCritico()) {
                hay = true;
                sb.append("⚠️ ").append(a.getNombre()).append(" (").append(a.getStock()).append(" unidades)\n");
            }
        }
        if (!hay) {
            sb.append("(no hay artículos en nivel crítico)\n");
        }
        areaTexto.setText(sb.toString());
    }

    private void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje);
    }
}