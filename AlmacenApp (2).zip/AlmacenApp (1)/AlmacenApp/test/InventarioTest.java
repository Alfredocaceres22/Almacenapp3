package test;

import modelo.Inventario;
import org.junit.Test;
import static org.junit.Assert.*;

public class InventarioTest {

    @Test
    public void testIngresoStock() {
        Inventario inv = new Inventario();
        inv.agregarArticulo("Café", 7);
        inv.registrarIngreso("Café", 5);
        assertEquals(12, inv.obtenerArticulos().get(0).getStock());
    }

    @Test
    public void testRetiroStockValido() {
        Inventario inv = new Inventario();
        inv.agregarArticulo("Café", 10);
        inv.registrarRetiro("Café", 3);
        assertEquals(7, inv.obtenerArticulos().get(0).getStock());
    }

    @Test
    public void testRetiroStockInvalido() {
        Inventario inv = new Inventario();
        inv.agregarArticulo("Café", 4);
        inv.registrarRetiro("Café", 6);
        assertEquals(4, inv.obtenerArticulos().get(0).getStock());
    }
}